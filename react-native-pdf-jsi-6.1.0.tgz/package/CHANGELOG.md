# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Changed

- `PdfView`: `onPageChange` now fires while scrolling, as soon as the page at the centre of the view changes, instead of waiting for scrolling to stop ([#43](https://github.com/126punith/react-native-pdf-jsi/issues/43)). Flings, paging snaps and animated `goToPage` jumps report the pages they pass through. `onScaleChange` still fires once zooming settles.
- Android: the prebuilt PDFium libraries are no longer in the npm package, which shrinks it from about 26 MB to about 2 MB unpacked. The first Android build downloads them from GitHub Releases, verifies the SHA-256 and caches them in the Gradle user home. For offline builds, set `pdfJsiPdfiumDir` or `pdfJsiPdfiumUrl` in `gradle.properties` (see the README), or the Expo plugin options `pdfiumDir` / `pdfiumUrl`.
- The package no longer includes source maps or the Android Gradle wrapper.

## [6.1.0] - 2026-10-22

### Fixed

- Android: remote PDFs are downloaded with the app's cookies from React Native's cookie store again, as in 4.x, so session-cookie authentication works. An explicit `Cookie` in `source.headers` takes precedence.

## [6.0.0] - 2026-10-20

Breaking release: a new viewer, native downloads and zero-based pages everywhere. Upgrade steps: [MIGRATION-6.0.md](MIGRATION-6.0.md).

### Added

- `PdfView`: Fabric viewer with `goToPage` / `zoomTo` commands, `fitPolicy`, paging, horizontal and RTL layouts, highlights, `onPageTap` / `onLinkPress` in page points, and `onPasswordRequired`. Page and scale events fire once scrolling settles.
- Android: Kotlin viewer on PDFium that renders one bitmap per page plus 512 px tiles when zoomed, on a single prioritised render thread with a byte-sized bitmap cache that shrinks on memory pressure.
- `PdfPage`: draws one page of an open `PdfDocument`, sized by its aspect ratio; unlocked and edited documents render without reopening.
- `usePdfDocument` hook.
- `PdfCache`: native downloads with ETag / Last-Modified revalidation, offline fallback, resume for large files, shared in-flight downloads and an LRU size limit. `PdfFiles.saveToDownloads`.
- `PdfDocument` editing that stays in memory until `save(path)`: `rotatePage`, `deletePage`, `movePage`, `insertPages`, `addAnnotation`, `setFormFieldValues`; password-protected save on iOS.
- `PdfDocument.renderPage` / `renderThumbnails` with `maxWidth`, `maxHeight`, `scale`, `format` and `quality`.
- `PdfError` with stable codes on every rejection and viewer error.
- TypeScript sources with generated type declarations.

### Changed

- Pages are 0-based in every API, including the viewer, managers and bookmarks.
- Viewer props and events renamed; see the migration guide.
- `BookmarkManager` takes its storage through `setStorage` instead of importing AsyncStorage.
- `react-native-nitro-modules` 0.37.x is the only native peer dependency.
- The Expo plugin sets `UIFileSharingEnabled` and `LSSupportsOpeningDocumentsInPlace` so files saved to Documents appear in the iOS Files app (opt out with `iosFileSharing: false`). `FileManager.openDownloadsFolder()` opens the app's own folder on iOS.
- Files downloaded with `cache: 'none'` are kept for 24 hours instead of being deleted on the next launch, so a stored path still opens after a restart.

### Removed

- The 5.x `Pdf` class component, `PDFJSI` helpers, `EnhancedPdfView`, `usePDFJSI`, `PdfViewFlatList`, `DoubleTapView`, `PinchZoomView`, `index.js.flow` and `PDFText.makeSearchablePDF`.
- Dependencies on AndroidPdfViewer, `io.legere:pdfiumandroid`, Gson, `react-native-blob-util`, AsyncStorage, `crypto-js` and `deprecated-react-native-prop-types`.

## [5.1.0] - Unreleased

Memory and resource leak fixes. Opening and closing the same PDF repeatedly no longer grows memory. No breaking API changes. Details: [MEMORY_LEAK_ANALYSIS.md](MEMORY_LEAK_ANALYSIS.md).

### Added

- Reference-counted document registry: `withPdfDocument`, `acquirePdf` / `releasePdf`, `invalidatePdf`, `trimPdfCache`, `closeAllPdfs`, `getPdfRegistryStats`. Released documents stay in a 2-document warm pool, which is emptied on memory warnings.
- Native documents report their size to the JS garbage collector (`getExternalMemorySize` on Android, `memorySize` on iOS).

### Changed

- `openPdf(path)` now pins the document until `closePdf(path)`. Internal helpers (`renderPageDirect`, `searchTextDirect`, `PDFText`, `ExportManager`, `usePDFJSI`, `EnhancedPdfView`, the `Pdf` JSI methods) no longer pin, so documents they open are closed once released.
- `Pdf` cancels an in-flight download on unmount and when `source` changes, and ignores results from superseded loads.

### Fixed

- Every opened native document stayed open for the life of the app.
- Each network download kept the unmounted `Pdf` component and its parent screen alive through a `react-native-blob-util` progress listener that is never removed.
- `Pdf` could throw `TypeError` when cancelling a previous download, and a stale download could overwrite a newer source.
- Android: each view left a "PDF renderer" thread running after it was dropped; `content://` sources leaked a file descriptor; ML Kit recognizer was not closed on error; JNI local references piled up in OCR and disk-cache calls; `splitPDF` leaked a document if saving failed.
- iOS: view teardown now always unregisters the search registry entry and releases the document; old documents are no longer kept after a failed or password-protected load; the search cache is bounded and cleared when the document changes; `exportToImages` encodes one page at a time.
- `usePDFJSI` performance history is capped at `maxCacheSize`; `EnhancedPdfView` and `usePDFJSI` no longer set state after unmount; `DoubleTapView` clears its timer on unmount and no longer fires a single tap twice.
- `mergePDFs` deletes the temp files it downloads for URL inputs. `BookmarkManager.getBookmarks` returns a copy. Analytics cache eviction is LRU and invalidation matches the exact PDF.

### Removed

- Unused `src/utils/PerformanceLogger.js`.

## [5.0.0] - 2026-10-06

Breaking release. Not a drop-in upgrade from 4.x. Install 5.0.0 only if the app already uses the React Native New Architecture and needs the Nitro JSI document API. Production apps on 4.x stay on 4.5.0. Upgrade steps: [MIGRATION-5.0.md](MIGRATION-5.0.md).

### Changed

- Document logic moves to Nitro HybridObjects (`PdfLibrary` / `PdfDocument`). The Fabric view only renders.
- Android PDF operations run on an in-process PDFium. iOS uses Swift PDFKit.
- Page indexes on the Nitro handle are 0-based. `renderPageDirect` and `searchTextDirect` still accept 1-based pages and convert them. Pass a file path; `pdfId` strings are rejected.

### Removed

- Old Architecture (Paper) view managers and bridge modules. There is no Paper fallback.
- Windows (`windows/`, `RCTPdf`).
- `pdfId` string API and `registerPathForSearch`.
- Native modules `PDFJSIManager`, `EnhancedPdfJSIBridge`, `PDFExporter`, `PDFTextModule`, `FileManager`, and `FileDownloader`.
- `createSearchablePDF`. `recognizeText(index, fast)` returns the recognized string.

### Added

- Required peer `react-native-nitro-modules`.
- iOS document picker compiled into the Nitro module.

## [4.5.0] - 2026-09-05

### OCR (text extraction + on-device recognition)

High-level overview of the new PDF text / OCR surface. Setup and examples: [README_OCR.md](README_OCR.md).

**What it is**
- **Embedded text** from digital PDFs (Pdfium on Android, PDFKit on iOS) via `PDFText` / `PDFTextModule` — no ML.
- **Optional on-device OCR** for scanned or image-only pages: iOS **Vision** (system, iOS 13+); Android **ML Kit** only when `pdfJsiEnableOcr=true` or Expo `["react-native-pdf-jsi", { "ocr": true }]`.
- Modes: `text` | `ocr` | `auto` on `PDFText.extract` (auto OCRs when page text is empty/sparse).
- Medium APIs: `extract` + `stats`, in-memory `recognizePage`, `toHighlightRects` / `blocksToHighlightRects`, `makeSearchablePDF`, and `setOCREngine` for custom models.
- Page-at-a-time processing so peak memory does not grow with page count.

**What it is not**
- Not a bundled custom CoreML / TFLite OCR model in the npm package.
- Not cloud OCR (Google Vision, Textract, etc.) as a default.
- Not Windows OCR.
- Not live OCR inside `searchTextDirect` — that API still searches the PDF **text layer** only. For scans, use `makeSearchablePDF` then search, or draw OCR boxes with `toHighlightRects`.

### Added
- **PDF text extraction + optional OCR plugin**
  - Native embedded-text APIs via new `PDFTextModule` (Android Pdfium / iOS PDFKit), exposed as `PDFText` and wired through `PDFTextExtractor` / `ExportManager.exportToText`.
  - Modes: `text` | `ocr` | `auto` (`PDFText.extract`). Auto OCRs pages with little/no text layer.
  - **iOS**: on-device OCR with Vision (`VNRecognizeTextRequest`, iOS 13+); Vision linked in the podspec.
  - **Android**: optional ML Kit Text Recognition when `pdfJsiEnableOcr=true` (or Expo plugin `{ ocr: true }`); core package stays free of ML Kit unless enabled.
  - **Custom engines**: `PDFText.setOCREngine` / `clearOCREngine` for CoreML, TFLite, or any `recognize(imagePath)` implementation.
  - Expo config plugin accepts `["react-native-pdf-jsi", { "ocr": true }]`.
- **Medium-effort OCR APIs**
  - `extract` always returns `stats` (`pagesNative` / `pagesOcr` / `pagesEmpty`).
  - `getPageSize`, `toHighlightRects` / `blocksToHighlightRects` for viewer `highlightRects`.
  - In-memory `recognizePage` (native bitmap → OCR); `extract` prefers it over temp export files.
  - `makeSearchablePDF` — image + invisible-text sandwich so `searchTextDirect` works on scanned docs.
  - Documented `ocrOptions.fast` / `languages` (iOS) in [README_OCR.md](README_OCR.md).

### Fixed
- **PDF compression reported 0% savings** – Fixes [#36](https://github.com/126punith/react-native-pdf-jsi/issues/36): `compressPDF` / `PDFCompressor` now perform PDF-aware recompression (page downsample + JPEG rebuild) on Android (`PdfRenderer`/`PdfDocument`) and iOS (PDFKit). Compression level maps to render scale and JPEG quality. If the recompressed file is not smaller than the original (common for text-only PDFs), the library falls back to a byte-identical copy so output stays valid. Whole-file zlib remains unused (still not PDF-safe; see #26).

## [4.4.1] - 2026-03-19

### Fixed
- **`page` prop not respected (controlled / list usage)** – Fixes [#13](https://github.com/126punith/react-native-pdf-jsi/issues/13): sync native navigation when only `page` changes after load (`componentDidUpdate` in `index.js`); stable `pdfId` for JSI `setPage` (`props.pdfId` or per-instance id); Android ignores stale `onPageChanged` during `jumpTo`; iOS Fabric `setNativePage` and Paper `setPage:` reset navigation state so re-applying the same page still navigates.
- **Android crash: `IllegalStateException: Already closed`** – Prevents crashes caused by a race condition between the background rendering thread (`RenderingHandler`) and the main thread calling `recycle()` during unmount.
  - Configures PdfiumAndroid to **ignore double-close attempts** by setting `AlreadyClosedBehavior.IGNORE` via `ConfigKt.setPdfiumConfig(new Config(new DefaultLogger(), AlreadyClosedBehavior.IGNORE))` in `PdfView`'s constructor.
  - Aligns behavior with the upstream fix in [`wonday/react-native-pdf` commit `3234127`](https://github.com/wonday/react-native-pdf/commit/32341278905678c09358ecc1e7c54cc8876b2af1), where closing an already-closed PDF resource is treated as a no-op instead of throwing.
- **PDFCompressor / `compressPDF` corrupted output (Android & iOS)** – Fixes [#26](https://github.com/126punith/react-native-pdf-jsi/issues/26): `StreamingPDFProcessor.compressPDFStreaming` no longer wraps the whole file in zlib (which produced a non-PDF stream). It now uses the existing streaming copy so the output file remains a valid PDF; size ratio is ~1 until a PDF-aware recompression path exists.

## [4.4.0] - 2025-03-08

### Added
- **Programmatic search and highlight (Android & iOS)** – Fixes [#24](https://github.com/126punith/react-native-pdf-jsi/issues/24)
  - **`searchTextDirect(pdfId, searchTerm, startPage, endPage)`** – Exported to JS; runs native PDF text search and returns `{ page, text, rect }[]` with bounding boxes in PDF coordinates.
  - **`pdfId` prop** – Optional stable ID for the current PDF (e.g. `"main-pdf"`). Required for `searchTextDirect` so the native side can resolve the document path.
  - **`highlightRects` prop** – Array of `{ page, rect }` (rect: `"left,top,right,bottom"` in PDF points). When set, the viewer draws semi-transparent yellow highlights over those regions. Supports zoom and scroll on both platforms.
  - **Path registration** – Path for search is registered when the PDF loads (from `onLoadComplete` and native `onDocumentChanged`). JS can also call `PDFJSIManager.registerPathForSearch(pdfId, path)` for explicit registration. Only local file paths are registered; URI paths are ignored to avoid search on non-downloaded sources.
- **Android**: `SearchRegistry` for `pdfId`→path and page dimensions; PDFium-based search with rect fallback; highlight drawing in `PdfView` with correct PDF-to-view scaling and Y-axis conversion.
- **iOS**: `SearchRegistry`, PDFKit `findString` search, `HighlightOverlayView` for drawing highlights; overlay redraw on zoom and scroll so highlights stay aligned with text.

### Fixed
- **iOS search returning 0 results**: Search now uses the local file path (from load/cache) instead of the original URI. Path is registered when the document loads and via JS after `onLoadComplete`. URI guard in native search prevents using `http(s):` paths.
- **iOS highlights misaligned after zoom/scroll**: Highlight overlay is redrawn in `scrollViewDidZoom`, `scrollViewDidEndZooming`, and `scrollViewDidScroll` so `convertRect:fromPage:` is re-evaluated and highlights stay aligned with the zoomed/scrolled content.
- **iOS PDFJSIManager build**: Replaced `(void *)doc` with `(__bridge void *)doc` for ARC; removed unused variables to clear compiler warnings.
- **.gitignore**: Added `.npmrc` to avoid committing auth tokens.

### Technical details
- **Android**: `SearchRegistry.java`, `PDFJSIManager.searchInPdf` with page-size registration and rect fallback, `PdfView`/`PdfManager` for `pdfId`/`highlightRects`, `registerPathForSearch` promise API.
- **iOS**: `SearchRegistry.h/m`, `PDFJSIManager.m` PDFKit search and `registerPathForSearch`, `RNPDFPdfView.mm` `HighlightOverlayView`, path registration in `setPdfId`/`updateProps`/`onDocumentChanged`, overlay redraw in scroll/zoom delegates.
- **JS**: `index.js` exports `searchTextDirect`, passes `pdfId`/`highlightRects`, calls `registerPathForSearch` in `onLoadComplete` handler; `src/PDFJSI.js` and Fabric spec updated for new props.

## [4.3.0] - 2025-02-02

### Added
- **Expo Support**: Added Expo config plugin for seamless integration with Expo development builds
  - New `app.plugin.js` entry point for Expo auto-discovery
  - `plugin/` directory with TypeScript source and compiled JavaScript
  - Automatic Jitpack repository configuration for Android
  - PDFKit framework linking for iOS
  - Works with `npx expo prebuild` and `npx expo run:ios/android`

### Technical Details
- **app.plugin.js**: Expo plugin entry point that exports the compiled plugin
- **plugin/src/index.ts**: Main plugin combining Android and iOS configurations
- **plugin/src/withPdfJsiAndroid.ts**: Adds Jitpack maven repository for AndroidPdfViewer dependency
- **plugin/src/withPdfJsiIos.ts**: Ensures PDFKit framework is properly linked
- **package.json**: Added `app.plugin` field, `expo` keywords, build scripts, and devDependencies

### Notes
- Expo Go is NOT supported (requires native code)
- Must use Expo development builds (`npx expo run:ios` or `npx expo run:android`)
- Compatible with Expo SDK 50+ and EAS Build

## [4.2.2] - 2025-01-31

### Fixed
- **PDFCompressor Module**: Fixed "Unable to resolve module react-native-pdf-jsi/src/PDFCompressor" error ([#17](https://github.com/126punith/react-native-pdf-jsi/issues/17))
  - Added missing `PDFCompressor.js` module to the library
  - Exported `PDFCompressor`, `CompressionPreset`, and `CompressionLevel` from both `src/index.js` and root `index.js`
  - Added TypeScript definitions for PDFCompressor in `index.d.ts`
- **iOS Compilation Error**: Fixed "Call to undeclared function 'RCTLogInfo'" error in `PDFExporter.m`
  - Added missing `#import <React/RCTLog.h>` import
- **Native Compression Bridge**: Added `compressPDF` method to `PDFExporter` native module on both Android and iOS
  - Bridges to existing `StreamingPDFProcessor` for actual compression
  - Returns detailed compression results (original size, compressed size, ratio, duration)
- **Compression Estimates**: Updated `estimateCompression()` to use realistic ratios (~15-18% savings)
  - Previous estimates claimed 50-75% savings which was unrealistic for zlib deflate on PDFs
  - Added accurate note explaining that all presets produce similar compression due to PDFs containing already-compressed content

### Technical Details
- **PDFExporter.java (Android)**: Added `compressPDF(inputPath, outputPath, compressionLevel, promise)` method that calls `StreamingPDFProcessor.compressPDFStreaming()`
- **PDFExporter.m (iOS)**: Added `compressPDF:outputPath:compressionLevel:resolver:rejecter:` method that calls `StreamingPDFProcessor compressPDFStreaming:`
- **PDFCompressor.js**: New module providing high-level compression API with presets (EMAIL, WEB, MOBILE, PRINT, ARCHIVE)

## [4.1.1] - 2025-01-05

### Fixed
- **iOS Pinch-to-Zoom**: Fixed critical issue where pinch-to-zoom gestures were not working on iOS devices
  - Removed interfering custom pinch gesture recognizer that was blocking PDFView's native pinch-to-zoom functionality
  - Enabled PDFView's native pinch gestures which work through its internal UIScrollView
  - Updated gesture recognizer delegate to allow simultaneous recognition with PDFView's internal gestures
  - Improved scale change event throttling to prevent excessive callbacks (0.01 threshold)
  - Pinch-to-zoom now works smoothly on iOS, matching Android behavior where native library handles gestures
- **Package Dependencies**: Removed incorrect self-dependency (`react-native-pdf-jsi: ^2.2.4`) from package.json that was causing package managers to install both v4.1.0 and v2.2.4 simultaneously

### Technical Details
- **RNPDFPdfView.mm (iOS)**: Removed custom `UIPinchGestureRecognizer` and `handlePinch:` method that was consuming pinch gestures without applying them to PDFView
- **RNPDFPdfView.mm (iOS)**: Explicitly enabled PDFView's native pinch gesture recognizers in gesture recognizer initialization loop
- **RNPDFPdfView.mm (iOS)**: Updated `onScaleChanged:` method with 0.01 threshold to reduce excessive callbacks for tiny scale changes
- **RNPDFPdfView.mm (iOS)**: Updated `gestureRecognizer:shouldRecognizeSimultaneouslyWithGestureRecognizer:` to allow PDFView's internal gestures to work simultaneously
- **package.json**: Removed self-dependency entry

This fix resolves [issue #11](https://github.com/126punith/react-native-pdf-jsi/issues/11) where pinch-to-zoom was not working on iOS while working correctly on Android, and [issue #12](https://github.com/126punith/react-native-pdf-jsi/issues/12) where the package incorrectly listed itself as a dependency causing circular dependency issues.

## [4.1.0] - 2025-12-30

### Fixed
- **Android onLoadComplete Callback**: Fixed critical issue where `onLoadComplete` prop was not firing on Android devices
  - **Note**: iOS was not affected by this issue. iOS uses a notification-based approach (`PDFViewDocumentChangedNotification`) which is inherently more reliable. This fix is Android-specific.
  - Added comprehensive error handling in `loadComplete()` to ensure events are always dispatched even if errors occur during page size retrieval, zoom operations, or table of contents serialization
  - Implemented delayed event dispatch using `Handler.post()` to ensure React component is mounted and ready before dispatching `loadComplete` event, fixing timing issues
  - Restored `drawPdf()` call in `onAfterUpdateTransaction()` to ensure PDF loads properly on initial mount
  - Added duplicate call prevention to avoid multiple `loadComplete` events
  - Added fallback dispatch mechanism in `drawPdf()` when skipping reload if PDF is already loaded but event wasn't dispatched
  - Enhanced logging for debugging event dispatch issues
  - Resets event tracking flags when PDF path changes to ensure `onLoadComplete` fires for new documents

### Technical Details
- **PdfView.java**: Added `loadCompleteDispatched` and `lastKnownPageCount` tracking flags, delayed dispatch mechanism, and comprehensive error handling
- **PdfManager.java**: Restored `drawPdf()` call in `onAfterUpdateTransaction()` method
- **RNPDFPdfView.mm (iOS)**: Updated `onDocumentChanged` to include file path in `loadComplete` message for consistency with Android format
- **index.js**: Added debug logging for event tracking in development mode

This fix resolves the regression similar to [react-native-pdf issue #899](https://github.com/wonday/react-native-pdf/issues/899) and ensures reliable `onLoadComplete` callback execution on Android. iOS implementation was also updated to include file path in the message format for consistency.

## [4.0.0] - 2025-12-13

### Added
- **iOS Pro Features Port**: Complete feature parity with Android - all pro features now available on iOS
  - File download and management (FileDownloader, FileManager)
  - PDF export operations (split, merge, extract, rotate, delete)
  - Export to images (PNG/JPEG)
  - PDF compression
  - Text extraction
- **iOS Performance Optimizations**:
  - ImagePool for efficient UIImage reuse and memory management
  - LazyMetadataLoader for deferred PDF metadata loading
  - MemoryMappedCache for zero-copy file access using mmap()
  - StreamingPDFProcessor for chunk-based processing of large files
- **Cross-Platform Compatibility**: Platform.OS checks for method signature differences (Android 3 args vs iOS 2 args for splitPDF)

### Fixed
- **TypeScript Definitions**: Fixed malformed comment blocks in `index.d.ts` that made functional props appear commented out
  - All props (spacing, password, renderActivityIndicator, enableAntialiasing, enablePaging, enableRTL, enableAnnotationRendering, enableDoubleTapZoom, fitPolicy) now properly documented
- **Android splitPDF**: Fixed argument count mismatch - Android requires 3 arguments (filePath, ranges, outputDir) while iOS requires 2 (filePath, ranges)
- **Promise Resolution**: Fixed EXC_BAD_ACCESS crashes by ensuring all promise callbacks execute on main thread
- **File Download**: Removed unstable native folder creation code, using react-native-blob-util for folder operations

### Changed
- **FileManager.js**: Removed subfolderName parameters, simplified to use react-native-blob-util for folder creation
- **ExportManager.js**: Removed folderName parameters, added Platform.OS compatibility checks
- **iOS FileDownloader**: Simplified implementation, removed subfolder creation logic
- **iOS FileManager**: Removed native createSubfolder method

## [3.4.2] - 2025-11-30

### Fixed
- **Android Compilation Error**: Fixed missing `setEnableMomentum` method implementation in `PdfManager.java` that was causing build failures with React Native codegen. The method is now implemented as a NOOP since Android's ScrollView handles momentum scrolling automatically.

## [3.4.1] - 2025-11-29

### Fixed
- Android and iOS build issues resolved

## [3.4.0] - 2025-11-29

### Added
- **Enhanced Navigation**: Added immediate page navigation support in `setPage()` method. The PDF now jumps to the specified page instantly when navigation is triggered programmatically.
- **Improved File Path Handling**: Added `downloadedFilePath` instance variable for reliable path tracking during PDF loading. This ensures file paths are available immediately, even before React state updates.
- **New `getPath()` Method**: Added public method to retrieve the current PDF file path. Returns the most reliable path source (instance variable > state path).
- **Enhanced Path Extraction**: Improved `onLoadComplete` callback to receive file path directly from native module, ensuring more reliable path availability for bookmarking, export, and PDF operations.

### Fixed
- **Navigation Reliability**: Fixed issue where programmatic page navigation would not scroll to the target page. The native `setPage()` method now calls `jumpTo()` immediately when the page changes.
- **File Path Availability**: Fixed issue where `pdfFilePath` was sometimes empty in `onLoadComplete`, causing failures in export and PDF operations. Path is now reliably extracted from multiple sources with proper fallbacks.
- **Native Event Handling**: Enhanced `loadComplete` event message format to include file path, improving reliability of path extraction in JavaScript.

### Changed
- **Native Message Format**: Updated `loadComplete` event format from `loadComplete|pages|width|height|tableContents` to `loadComplete|pages|width|height|path|tableContents` for backward compatibility with automatic detection of old/new formats.
- **Path Tracking**: File paths are now stored in an instance variable (`downloadedFilePath`) immediately upon file preparation/download completion, in addition to React state, ensuring synchronous access.

## [3.3.0] - Previous Version

Previous release notes...

