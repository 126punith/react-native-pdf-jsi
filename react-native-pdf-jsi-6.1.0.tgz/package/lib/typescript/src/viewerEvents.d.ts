import type { PdfErrorCode } from './errors';
import type { OutlineItem, PdfRect } from './specs/PdfLibrary.nitro';
export interface PdfLoadEvent {
    pageCount: number;
    /** First page size in PDF points. */
    width: number;
    height: number;
    path: string;
    outline: OutlineItem[];
}
export interface PdfPageChangeEvent {
    /** Zero-based page under the centre of the viewport (the last page once scrolled to the end). */
    page: number;
    pageCount: number;
}
export interface PdfScaleChangeEvent {
    /** Relative to the fitted page: 1 means the page fits as `fitPolicy` says. */
    scale: number;
}
export interface PdfPageTapEvent {
    page: number;
    /** PDF points from the page's top-left corner. */
    x: number;
    y: number;
}
export interface PdfLinkPressEvent {
    url: string;
}
export interface PdfPasswordRequiredEvent {
    /** A password was given and it was wrong. */
    incorrect: boolean;
}
export interface PdfHighlight {
    page: number;
    rect: PdfRect;
}
export type ViewerEvent = ({
    type: 'load';
} & PdfLoadEvent) | ({
    type: 'pageChange';
} & PdfPageChangeEvent) | ({
    type: 'scaleChange';
} & PdfScaleChangeEvent) | ({
    type: 'tap';
} & PdfPageTapEvent) | ({
    type: 'link';
} & PdfLinkPressEvent) | ({
    type: 'passwordRequired';
} & PdfPasswordRequiredEvent) | {
    type: 'error';
    code: PdfErrorCode;
    message: string;
    page?: number;
};
/** Parses the JSON `message` of the native `onChange` event. Returns `null` for anything unknown. */
export declare function parseViewerEvent(message: string | null | undefined): ViewerEvent | null;
//# sourceMappingURL=viewerEvents.d.ts.map