/**
 * AnalyticsManager Class with Memoization
 */
export class AnalyticsManager {
    initialized: boolean;
    memoizer: MemoizedAnalytics;
    /**
     * Initialize analytics
     */
    initialize(): Promise<void>;
    /**
     * OPTIMIZED: Get complete analytics for a PDF with memoization
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<Object>} Complete analytics
     */
    getAnalytics(pdfId: string): Promise<Object>;
    /**
     * Invalidate analytics cache when data changes
     * Call this when bookmarks or progress is updated
     * @param {string} pdfId - PDF identifier
     */
    invalidateCache(pdfId: string): void;
    /**
     * Get memoization statistics
     * @returns {Object} Cache statistics
     */
    getCacheStatistics(): Object;
    /**
     * Calculate reading metrics
     */
    calculateReadingMetrics(progress: any): {
        pagesPerHour: number;
        minutesPerPage: number;
        completionRate: number;
        wordsPerMinute: number;
        totalPagesRead: any;
        totalPages: any;
        timeSpent: number;
        estimatedTotalTime: {
            seconds: number;
            minutes: number;
            hours: number;
            formatted: string;
        } | null;
        estimatedTimeRemaining: {
            seconds: number;
            minutes: number;
            hours: number;
            formatted: string;
        } | null;
    };
    /**
     * Calculate engagement metrics
     */
    calculateEngagement(progress: any, bookmarks: any): {
        totalBookmarks: any;
        uniqueBookmarkedPages: number;
        bookmarkRate: number;
        averageBookmarksPerPage: number;
        engagementScore: number;
    };
    /**
     * Calculate engagement score (0-100)
     */
    calculateEngagementScore(progress: any, bookmarks: any): number;
    /**
     * Analyze page patterns
     */
    analyzePages(progress: any, bookmarks: any): {
        mostBookmarkedPages: {
            page: number;
            bookmarks: any;
        }[];
        readingGaps: {
            start: any;
            end: number;
            size: number;
        }[];
        readingPattern: string;
        heatmap: {};
    };
    /**
     * Find gaps in reading (unread sections)
     */
    findReadingGaps(pagesRead: any, totalPages: any): {
        start: any;
        end: number;
        size: number;
    }[];
    /**
     * Identify reading pattern (linear, random, skip)
     */
    identifyReadingPattern(pagesRead: any): "mixed" | "insufficient_data" | "linear" | "selective";
    /**
     * Analyze time patterns
     */
    analyzeTime(progress: any): {
        averageSessionTime: number;
        totalTime: number;
        efficiency: number;
        totalTimeSeconds?: undefined;
        totalTimeMinutes?: undefined;
        totalTimeHours?: undefined;
        totalSessions?: undefined;
        averageSessionMinutes?: undefined;
        formattedTotalTime?: undefined;
        formattedAverageSession?: undefined;
    } | {
        totalTimeSeconds: any;
        totalTimeMinutes: number;
        totalTimeHours: number;
        totalSessions: any;
        averageSessionTime: number;
        averageSessionMinutes: number;
        efficiency: number;
        formattedTotalTime: string;
        formattedAverageSession: string;
        totalTime?: undefined;
    };
    /**
     * Estimate total reading time
     */
    estimateTotalTime(progress: any): {
        seconds: number;
        minutes: number;
        hours: number;
        formatted: string;
    } | null;
    /**
     * Estimate time remaining
     */
    estimateTimeRemaining(progress: any): {
        seconds: number;
        minutes: number;
        hours: number;
        formatted: string;
    } | null;
    /**
     * Generate predictions
     */
    generatePredictions(progress: any): {
        completionDate: null;
        remainingSessions: null;
        message: string;
        sessionsRemaining?: undefined;
        completionDateFormatted?: undefined;
        pagesPerSession?: undefined;
        estimatedDaysToComplete?: undefined;
    } | {
        sessionsRemaining: number;
        completionDate: string;
        completionDateFormatted: string;
        pagesPerSession: number;
        estimatedDaysToComplete: number;
        remainingSessions?: undefined;
        message?: undefined;
    };
    /**
     * Generate personalized insights
     */
    generateInsights(progress: any, bookmarks: any, statistics: any): ({
        type: string;
        icon: string;
        title: string;
        message: string;
        sentiment: string;
        action?: undefined;
    } | {
        type: string;
        icon: string;
        title: string;
        message: string;
        sentiment: string;
        action: {
            type: string;
            page: any;
        };
    })[];
    /**
     * Calculate reading streak
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<Object>} Streak information
     */
    getReadingStreak(pdfId: string): Promise<Object>;
    /**
     * Get reading history
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<Array>} Reading history
     */
    getReadingHistory(pdfId: string): Promise<any[]>;
    /**
     * Compare with average reader
     */
    getComparison(progress: any): {
        speedComparison: {
            user: number;
            average: number;
            percentile: number;
        };
        thoroughness: {
            user: number;
            average: number;
            message: string;
        };
        engagement: {
            user: any;
            message: string;
        };
    };
    /**
     * Calculate percentile
     */
    calculatePercentile(userValue: any, avgValue: any): 10 | 50 | 90 | 75 | 25;
    /**
     * Generate reading recommendations
     */
    generateRecommendations(progress: any, bookmarks: any): ({
        type: string;
        priority: string;
        title: string;
        message: string;
        action: {
            type: string;
            page: any;
        };
    } | {
        type: string;
        priority: string;
        title: string;
        message: string;
        action: {
            type: string;
            page?: undefined;
        };
    })[];
    /**
     * Format duration in human-readable form
     */
    formatDuration(seconds: any): string;
    /**
     * Get empty metrics (when no data)
     */
    getEmptyMetrics(): {
        pagesPerHour: number;
        minutesPerPage: number;
        completionRate: number;
        wordsPerMinute: number;
        totalPagesRead: number;
        totalPages: number;
        timeSpent: number;
        estimatedTotalTime: null;
        estimatedTimeRemaining: null;
    };
    /**
     * Export analytics data
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<Object>} Export data
     */
    exportAnalytics(pdfId: string): Promise<Object>;
}
export default analyticsManager;
import MemoizedAnalytics from '../utils/MemoizedAnalytics';
declare const analyticsManager: AnalyticsManager;
//# sourceMappingURL=AnalyticsManager.d.ts.map