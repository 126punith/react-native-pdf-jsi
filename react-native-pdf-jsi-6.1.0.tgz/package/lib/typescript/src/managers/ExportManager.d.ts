export namespace ExportFormat {
    let TEXT: string;
    let JPEG: string;
    let PNG: string;
    let PDF: string;
}
export namespace ExportQuality {
    let LOW: number;
    let MEDIUM: number;
    let HIGH: number;
    let BEST: number;
}
export class ExportManager {
    isAvailable(): boolean;
    /**
     * @param {string} filePath
     * @param {{ pages?: number[], includePageNumbers?: boolean, separator?: string }} options zero-based pages
     */
    exportToText(filePath: string, options?: {
        pages?: number[];
        includePageNumbers?: boolean;
        separator?: string;
    }): Promise<string>;
    /** @param {number} page zero-based */
    exportPageToText(filePath: any, page: number): Promise<string>;
    /**
     * Renders pages to image files.
     * @returns {Promise<string[]>} image paths
     */
    exportToImages(filePath: any, options?: {}): Promise<string[]>;
    /**
     * @param {number} page zero-based
     * @returns {Promise<string>} image path
     */
    exportPageToImage(filePath: any, page: number, options?: {}): Promise<string>;
    /** Downloads http(s) URLs natively; local paths are returned as they are. */
    resolveMergePath(filePath: any): Promise<string>;
    mergePDFs(filePaths: any, outputPath?: null): Promise<string>;
    /**
     * @param {Array<[number, number]>} ranges zero-based inclusive [start, end] pairs
     * @returns {Promise<string[]>}
     */
    splitPDF(filePath: any, ranges: Array<[number, number]>, outputDir?: null): Promise<string[]>;
    /** @param {number[]} pages zero-based */
    extractPages(filePath: any, pages: number[], outputPath?: null): Promise<string>;
    _editAndSave(filePath: any, outputPath: any, edit: any): Promise<string>;
    /** @param {Record<number, number>} rotations zero-based page -> degrees */
    rotatePages(filePath: any, rotations: Record<number, number>, outputPath?: null): Promise<string>;
    /** @param {number[]} pages zero-based */
    deletePages(filePath: any, pages: number[], outputPath?: null): Promise<string>;
    share(content: any, options?: {}): Promise<import("react-native").ShareAction>;
    exportAndShareText(filePath: any, options?: {}): Promise<import("react-native").ShareAction>;
    /** @param {number} page zero-based */
    exportAndShareImage(filePath: any, page: number, options?: {}): Promise<import("react-native").ShareAction>;
    /** @param {number[]} pages zero-based */
    exportPagesToImages(filePath: any, pages: number[], options?: {}, onProgress?: null): Promise<string[]>;
    /** @param {number[]} pages zero-based */
    exportPagesToText(filePath: any, pages: number[], onProgress?: null): Promise<Map<number, string>>;
    getCapabilities(): {
        exportToText: boolean;
        exportToImages: boolean;
        mergePDFs: boolean;
        splitPDF: boolean;
        extractPages: boolean;
        rotatePages: boolean;
        deletePages: boolean;
        ocrViaPDFText: boolean;
        share: boolean;
    };
    getModuleInfo(): {
        isAvailable: boolean;
        platform: "ios" | "android" | "windows" | "macos" | "web";
        version: string;
        cacheDirectory: string;
        capabilities: {
            exportToText: boolean;
            exportToImages: boolean;
            mergePDFs: boolean;
            splitPDF: boolean;
            extractPages: boolean;
            rotatePages: boolean;
            deletePages: boolean;
            ocrViaPDFText: boolean;
            share: boolean;
        };
    };
}
export default exportManager;
declare const exportManager: ExportManager;
//# sourceMappingURL=ExportManager.d.ts.map