/**
 * BookmarkManager - Smart Bookmark Management System
 * Handles bookmark CRUD operations and reading progress tracking
 *
 * LICENSE:
 * - Basic bookmarks (CRUD): MIT License (Free)
 * - Enhanced features (colors, analytics): Commercial License (Paid)
 *
 * @author Punith M
 * @version 1.0.0
 */
/**
 * Storage the app provides through `bookmarkManager.setStorage(adapter)`.
 * AsyncStorage, MMKV (wrapped in promises) or any key-value store fits:
 *
 *     import AsyncStorage from '@react-native-async-storage/async-storage';
 *     bookmarkManager.setStorage(AsyncStorage);
 *
 * Without an adapter, bookmarks live in memory for the session.
 */
export function createMemoryStorage(): {
    getItem: (key: any) => Promise<any>;
    setItem: (key: any, value: any) => Promise<void>;
    removeItem: (key: any) => Promise<void>;
};
/**
 * BookmarkManager Class
 */
export class BookmarkManager {
    bookmarks: Map<any, any>;
    progress: Map<any, any>;
    initialized: boolean;
    storage: {
        getItem: (key: any) => Promise<any>;
        setItem: (key: any, value: any) => Promise<void>;
        removeItem: (key: any) => Promise<void>;
    };
    /**
     * Sets where bookmarks and progress are stored. Call before the first use;
     * the next call reloads from the new storage.
     * @param {{ getItem(key: string): Promise<string|null>, setItem(key: string, value: string): Promise<void>, removeItem(key: string): Promise<void> }} storage
     */
    setStorage(storage: {
        getItem(key: string): Promise<string | null>;
        setItem(key: string, value: string): Promise<void>;
        removeItem(key: string): Promise<void>;
    }): void;
    /**
     * Initialize bookmark manager
     * Load bookmarks and progress from the configured storage
     */
    initialize(): Promise<void>;
    /**
     * Save bookmarks to the configured storage
     */
    saveBookmarks(): Promise<void>;
    /**
     * Save progress to the configured storage
     */
    saveProgress(): Promise<void>;
    /**
     * Create a bookmark
     * @param {string} pdfId - PDF identifier
     * @param {Object} bookmark - Bookmark data
     * @returns {Promise<Object>} Created bookmark
     */
    createBookmark(pdfId: string, bookmark: Object): Promise<Object>;
    /**
     * Get all bookmarks for a PDF
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<Array>} Array of bookmarks
     */
    getBookmarks(pdfId: string): Promise<any[]>;
    /**
     * Get bookmark by ID
     * @param {string} pdfId - PDF identifier
     * @param {string} bookmarkId - Bookmark ID
     * @returns {Promise<Object|null>} Bookmark or null
     */
    getBookmark(pdfId: string, bookmarkId: string): Promise<Object | null>;
    /**
     * Update a bookmark
     * @param {string} pdfId - PDF identifier
     * @param {string} bookmarkId - Bookmark ID
     * @param {Object} updates - Fields to update
     * @returns {Promise<Object>} Updated bookmark
     */
    updateBookmark(pdfId: string, bookmarkId: string, updates: Object): Promise<Object>;
    /**
     * Delete a bookmark
     * @param {string} pdfId - PDF identifier
     * @param {string} bookmarkId - Bookmark ID
     * @returns {Promise<boolean>} Success status
     */
    deleteBookmark(pdfId: string, bookmarkId: string): Promise<boolean>;
    /**
     * Delete all bookmarks for a PDF
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<number>} Number of bookmarks deleted
     */
    deleteAllBookmarks(pdfId: string): Promise<number>;
    /**
     * Get bookmarks by page
     * @param {string} pdfId - PDF identifier
     * @param {number} page - Page number
     * @returns {Promise<Array>} Bookmarks on that page
     */
    getBookmarksOnPage(pdfId: string, page: number): Promise<any[]>;
    /**
     * Check if page has bookmark
     * @param {string} pdfId - PDF identifier
     * @param {number} page - Page number
     * @returns {Promise<boolean>} True if page has bookmark
     */
    hasBookmarkOnPage(pdfId: string, page: number): Promise<boolean>;
    /**
     * Update reading progress
     * @param {string} pdfId - PDF identifier
     * @param {Object} progressData - Progress data
     */
    updateProgress(pdfId: string, progressData: Object): Promise<any>;
    /**
     * Get reading progress
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<Object>} Progress data
     */
    getProgress(pdfId: string): Promise<Object>;
    /**
     * Get all reading progress
     * @returns {Promise<Array>} Array of progress for all PDFs
     */
    getAllProgress(): Promise<any[]>;
    /**
     * Delete reading progress
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<boolean>} Success status
     */
    deleteProgress(pdfId: string): Promise<boolean>;
    /**
     * Get statistics for a PDF
     * @param {string} pdfId - PDF identifier
     * @returns {Promise<Object>} Statistics
     */
    getStatistics(pdfId: string): Promise<Object>;
    /**
     * Generate unique ID
     * @returns {string} Unique ID
     */
    generateId(): string;
    /**
     * Export bookmarks and progress
     * @param {string} pdfId - PDF identifier (optional, exports all if not provided)
     * @returns {Promise<Object>} Export data
     */
    exportData(pdfId?: string): Promise<Object>;
    /**
     * Import bookmarks and progress
     * @param {Object} data - Import data
     * @returns {Promise<Object>} Import summary
     */
    importData(data: Object): Promise<Object>;
    /**
     * Clear all data (use with caution!)
     */
    clearAll(): Promise<void>;
    /**
     * Get storage size estimate
     * @returns {Promise<Object>} Size information
     */
    getStorageSize(): Promise<Object>;
}
export default bookmarkManager;
declare const bookmarkManager: BookmarkManager;
//# sourceMappingURL=BookmarkManager.d.ts.map