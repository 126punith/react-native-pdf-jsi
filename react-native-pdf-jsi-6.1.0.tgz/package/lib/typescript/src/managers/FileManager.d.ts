export default FileManager;
/** File helpers backed by the native PdfCache module (no react-native-blob-util). */
declare class FileManager {
    static openDownloadsFolder(): Promise<boolean>;
    /**
     * Android: copies into the public Downloads folder through MediaStore and
     * returns its content:// URI. iOS: copies into the app's Documents folder
     * and returns the path. The folder only shows in the Files app when the
     * app's Info.plist sets UIFileSharingEnabled and LSSupportsOpeningDocumentsInPlace.
     */
    static downloadToPublicFolder(sourcePath: any, fileName: any, mimeType?: string): Promise<string>;
    static downloadMultipleFiles(files: any): Promise<string[]>;
}
//# sourceMappingURL=FileManager.d.ts.map