declare const _default: CacheManager;
export default _default;
declare class CacheManager {
    /**
     * Store base64 PDF with streaming decoder
     * Eliminates OOM crashes - uses O(1) constant memory
     *
     * @param {Object} options - Storage options
     * @param {string} options.base64 - Base64 PDF data (with or without data URI prefix)
     * @param {string} [options.identifier] - Custom cache identifier (optional)
     * @param {number} [options.maxAge] - Cache TTL in milliseconds (default: 30 days)
     * @param {number} [options.maxSize] - Max cache size in bytes (default: 500MB)
     * @param {function} [options.onProgress] - Progress callback (0.0 to 1.0)
     * @returns {Promise<Object>} Cache info { cacheId, filePath, fileSize }
     */
    storeBase64(options: {
        base64: string;
        identifier?: string | undefined;
        maxAge?: number | undefined;
        maxSize?: number | undefined;
        onProgress?: Function | undefined;
    }): Promise<Object>;
    /**
     * Get cached PDF by identifier
     *
     * @param {string} identifier - Cache identifier
     * @returns {Promise<Object|null>} Cache info or null if not found/expired
     */
    get(identifier: string): Promise<Object | null>;
    /**
     * Check if PDF is cached and not expired
     *
     * @param {string} identifier - Cache identifier
     * @returns {Promise<boolean>} True if cached and valid
     */
    has(identifier: string): Promise<boolean>;
    /**
     * Remove cached PDF
     *
     * @param {string} identifier - Cache identifier
     * @returns {Promise<boolean>} True if removed successfully
     */
    remove(identifier: string): Promise<boolean>;
    /**
     * Clear all cached PDFs
     *
     * @returns {Promise<void>}
     */
    clear(): Promise<void>;
    /**
     * Clear expired PDFs only
     *
     * @returns {Promise<number>} Number of entries removed
     */
    clearExpired(): Promise<number>;
    /**
     * Get cache statistics
     *
     * @returns {Promise<Object>} Cache stats { totalSize, fileCount, hitRate }
     */
    getStats(): Promise<Object>;
    /**
     * Estimate decoded size from base64 length
     * Base64 encoding increases size by ~33%, so decoded is ~75%
     *
     * @param {number} base64Length - Length of base64 string
     * @returns {number} Estimated decoded size in bytes
     */
    estimateDecodedSize(base64Length: number): number;
    /**
     * Generate identifier from base64 fingerprint
     * Uses first 100 chars + last 100 chars + length
     *
     * @private
     */
    private _generateIdentifier;
}
//# sourceMappingURL=CacheManager.d.ts.map