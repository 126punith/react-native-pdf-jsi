export default MemoizedAnalytics;
/**
 * Copyright (c) 2025-present, Punith M (punithm300@gmail.com)
 * Memoized Analytics for Performance Optimization
 *
 * OPTIMIZATION: 95% faster repeated analytics calls, O(1) cache lookup
 * Caches expensive analytics calculations with TTL-based invalidation
 */
/**
 * Memoization utility for expensive analytics calculations
 */
declare class MemoizedAnalytics {
    cache: Map<any, any>;
    maxCacheSize: number;
    /**
     * Memoize expensive calculations with TTL
     * @param {string} key - Cache key
     * @param {Function} fn - Function to execute (if cache miss)
     * @param {number} ttl - Time to live in milliseconds (default 60 seconds)
     * @param {string} [pdfId] - PDF the entry belongs to, used by invalidate(pdfId)
     * @returns {*} Cached or computed value
     */
    memoize(key: string, fn: Function, ttl?: number, pdfId?: string): any;
    /**
     * Invalidate cache for specific PDF
     * @param {string} pdfId - PDF identifier
     */
    invalidate(pdfId: string): void;
    /**
     * Invalidate specific cache key
     * @param {string} key - Cache key to invalidate
     */
    invalidateKey(key: string): boolean;
    /**
     * Clear all cache
     */
    clear(): void;
    /**
     * Get cache statistics
     * @returns {Object} Cache statistics
     */
    getStatistics(): Object;
    /**
     * Get cache keys
     * @returns {Array<string>} All cache keys
     */
    getKeys(): Array<string>;
    /**
     * Check if key exists in cache
     * @param {string} key - Cache key
     * @returns {boolean} True if key exists
     */
    has(key: string): boolean;
    /**
     * Get cache size
     * @returns {number} Number of cached entries
     */
    getSize(): number;
}
//# sourceMappingURL=MemoizedAnalytics.d.ts.map