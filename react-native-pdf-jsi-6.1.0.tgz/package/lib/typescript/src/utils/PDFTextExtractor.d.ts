export default PDFTextExtractor;
/**
 * PDFTextExtractor Class
 */
declare class PDFTextExtractor {
    /**
     * Check if text extraction is available
     * @returns {boolean} True if text extraction is available
     */
    static isTextExtractionAvailable(): boolean;
    /**
     * Extract text from a specific page
     * @param {string} filePath - Path to PDF file
     * @param {number} pageNumber - Page number (0-indexed)
     * @returns {Promise<string>} Extracted text content
     */
    static extractTextFromPage(filePath: string, pageNumber: number): Promise<string>;
    /**
     * Extract text from multiple pages
     * @param {string} filePath - Path to PDF file
     * @param {Array<number>} pageIndices - Array of page indices (0-indexed)
     * @returns {Promise<Map<number, string>>} Map of page index to extracted text
     */
    static extractTextFromPages(filePath: string, pageIndices: Array<number>): Promise<Map<number, string>>;
    /**
     * Extract text from all pages
     * @param {string} filePath - Path to PDF file
     * @returns {Promise<Map<number, string>>} Map of page index to extracted text
     */
    static extractAllText(filePath: string): Promise<Map<number, string>>;
    /**
     * Get page count
     * @param {string} filePath - Path to PDF file
     * @returns {Promise<number>} Number of pages
     */
    static getPageCount(filePath: string): Promise<number>;
}
//# sourceMappingURL=PDFTextExtractor.d.ts.map