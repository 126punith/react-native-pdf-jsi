export namespace SamplePDFs {
    namespace SMALL {
        let name: string;
        let uri: string;
        let cache: boolean;
        let description: string;
        let expectedPages: number;
    }
    namespace MEDIUM {
        let name_1: string;
        export { name_1 as name };
        let uri_1: string;
        export { uri_1 as uri };
        let cache_1: boolean;
        export { cache_1 as cache };
        let description_1: string;
        export { description_1 as description };
        let expectedPages_1: number;
        export { expectedPages_1 as expectedPages };
    }
    namespace LARGE {
        let name_2: string;
        export { name_2 as name };
        let uri_2: string;
        export { uri_2 as uri };
        let cache_2: boolean;
        export { cache_2 as cache };
        let description_2: string;
        export { description_2 as description };
        let expectedPages_2: number;
        export { expectedPages_2 as expectedPages };
    }
}
export namespace TestScenarios {
    namespace BOOKMARKS {
        let name_3: string;
        export { name_3 as name };
        export let steps: string[];
    }
    namespace EXPORT {
        let name_4: string;
        export { name_4 as name };
        let steps_1: string[];
        export { steps_1 as steps };
    }
    namespace OPERATIONS {
        let name_5: string;
        export { name_5 as name };
        let steps_2: string[];
        export { steps_2 as steps };
    }
    namespace ANALYTICS {
        let name_6: string;
        export { name_6 as name };
        let steps_3: string[];
        export { steps_3 as steps };
    }
}
export const SampleBookmarks: {
    page: number;
    name: string;
    color: string;
    notes: string;
}[];
declare namespace _default {
    export { SamplePDFs };
    export { TestScenarios };
    export { SampleBookmarks };
}
export default _default;
//# sourceMappingURL=TestData.d.ts.map