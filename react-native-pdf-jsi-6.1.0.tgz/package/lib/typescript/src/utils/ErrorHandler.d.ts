export class PDFError extends Error {
    constructor(message: any, code: any, details: any);
    code: any;
    details: any;
}
export namespace ErrorCodes {
    let LICENSE_INVALID: string;
    let LICENSE_EXPIRED: string;
    let LICENSE_REQUIRED: string;
    let PDF_NOT_FOUND: string;
    let PDF_CORRUPTED: string;
    let PDF_PASSWORD_REQUIRED: string;
    let PDF_LOAD_TIMEOUT: string;
    let NETWORK_ERROR: string;
    let NETWORK_TIMEOUT: string;
    let STORAGE_FULL: string;
    let STORAGE_PERMISSION: string;
    let EXPORT_FAILED: string;
    let OPERATION_FAILED: string;
    let BOOKMARK_FAILED: string;
    let JSI_NOT_AVAILABLE: string;
    let NATIVE_MODULE_MISSING: string;
    let UNKNOWN_ERROR: string;
}
export function getUserFriendlyMessage(error: any): any;
export function handleError(error: any, context: any, showAlert: boolean | undefined, onRetry: any): void;
export function withErrorHandling(fn: any, context: any, onError: any): Promise<any>;
export function validatePDFPath(path: any): void;
export function validatePageNumber(page: any, totalPages: any): void;
declare namespace _default {
    export { PDFError };
    export { ErrorCodes };
    export { getUserFriendlyMessage };
    export { handleError };
    export { withErrorHandling };
    export { validatePDFPath };
    export { validatePageNumber };
}
export default _default;
//# sourceMappingURL=ErrorHandler.d.ts.map