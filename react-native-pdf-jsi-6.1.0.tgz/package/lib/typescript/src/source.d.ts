import type { PdfCacheMode } from './specs/PdfCache.nitro';
export type { PdfCacheMode };
/** A remote document (`http(s)://`) or a local URI (`file://`, `content://`, `bundle-assets://`). */
export interface PdfUriSource {
    uri: string;
    /** Request headers for remote documents. Keep values ASCII. */
    headers?: Record<string, string>;
    /** `true` is `'session'`, `false` is `'none'`. Defaults to `'session'`. */
    cache?: PdfCacheMode | boolean;
    /** A stored copy younger than this is used without asking the server. */
    maxAgeMs?: number;
    /** Cache key instead of the URL and headers, for signed URLs that change. */
    cacheKey?: string;
}
/** An absolute path to a file on the device. */
export interface PdfFileSource {
    filePath: string;
}
/** The document's bytes as standard base64, without a `data:` prefix. */
export interface PdfBase64Source {
    base64: string;
}
/** `require('./file.pdf')` */
export type PdfAssetSource = number;
export type PdfSource = PdfUriSource | PdfFileSource | PdfBase64Source | PdfAssetSource;
export type NormalizedSource = {
    kind: 'remote';
    url: string;
    headers: Record<string, string>;
    cache: PdfCacheMode;
    maxAgeMs?: number;
    cacheKey?: string;
} | {
    kind: 'local';
    uri: string;
} | {
    kind: 'base64';
    base64: string;
};
export type AssetResolver = (asset: number) => {
    uri: string;
} | null | undefined;
/** Validates a source and turns it into the single shape the loader handles. Throws `invalid-source`. */
export declare function normalizeSource(source: PdfSource, resolveAsset?: AssetResolver): NormalizedSource;
/** Compares normalized sources by value, so an inline object literal does not reload the document. */
export declare function sameSource(a: NormalizedSource | null, b: NormalizedSource | null): boolean;
/** FNV-1a over the text plus its length: a stable file name for a base64 document. */
export declare function base64Identifier(base64: string): string;
//# sourceMappingURL=source.d.ts.map