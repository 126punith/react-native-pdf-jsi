import * as React from 'react';
import type { StyleProp, ViewProps, ViewStyle } from 'react-native';
import { PdfError } from './errors';
import type { PdfLoadProgress } from './PdfCache';
import type { PdfSource } from './source';
import type { PdfHighlight, PdfLinkPressEvent, PdfLoadEvent, PdfPageChangeEvent, PdfPageTapEvent, PdfPasswordRequiredEvent, PdfScaleChangeEvent } from './viewerEvents';
export type PdfFitPolicy = 'width' | 'height' | 'page';
export interface PdfViewProps extends Omit<ViewProps, 'children' | 'style'> {
    source: PdfSource;
    /** Changing it reopens the document; a downloaded file is reused. */
    password?: string;
    /** Zero-based page shown first. Applied once per loaded document; use `goToPage` afterwards. */
    initialPage?: number;
    /** Zoom shown first, relative to the fitted page. Applied once per loaded document. */
    initialScale?: number;
    /** Relative to the fitted page. Defaults to 1. */
    minScale?: number;
    /** Relative to the fitted page. Defaults to 4. */
    maxScale?: number;
    horizontal?: boolean;
    /** One page per swipe. */
    enablePaging?: boolean;
    /** Right-to-left page order in horizontal layouts. */
    enableRTL?: boolean;
    /** Shows only `initialPage`, without scrolling or zooming. Touches reach the parent. */
    singlePage?: boolean;
    /** How a page is scaled at zoom 1. Defaults to `'width'`. */
    fitPolicy?: PdfFitPolicy;
    /** dp / pt between pages. Defaults to 8. */
    spacing?: number;
    enableDoubleTapZoom?: boolean;
    scrollEnabled?: boolean;
    enableAnnotationRendering?: boolean;
    showsHorizontalScrollIndicator?: boolean;
    showsVerticalScrollIndicator?: boolean;
    /** Rectangles drawn over pages, for example search matches. */
    highlights?: readonly PdfHighlight[];
    style?: StyleProp<ViewStyle>;
    /** Shown while the document downloads or opens. `null` hides the default spinner. */
    renderActivityIndicator?: ((progress: PdfLoadProgress | null) => React.ReactNode) | null;
    onLoadProgress?: (progress: PdfLoadProgress) => void;
    onLoad?: (event: PdfLoadEvent) => void;
    onPageChange?: (event: PdfPageChangeEvent) => void;
    onScaleChange?: (event: PdfScaleChangeEvent) => void;
    onPageTap?: (event: PdfPageTapEvent) => void;
    onLinkPress?: (event: PdfLinkPressEvent) => void;
    onPasswordRequired?: (event: PdfPasswordRequiredEvent) => void;
    onError?: (error: PdfError) => void;
}
export interface NavigationOptions {
    /** Defaults to true. */
    animated?: boolean;
}
export interface PdfViewRef {
    /** Zero-based; clamped to the last page. Ignored before `onLoad` and for values that are not whole numbers. */
    goToPage(page: number, options?: NavigationOptions): void;
    /** Relative to the fitted page; clamped to `[minScale, maxScale]`. `zoomTo(1)` resets the zoom. */
    zoomTo(scale: number, options?: NavigationOptions): void;
    /** Local path of the displayed document, once loaded. */
    getPath(): string | null;
}
export declare const PdfView: React.ForwardRefExoticComponent<PdfViewProps & React.RefAttributes<PdfViewRef>>;
export default PdfView;
//# sourceMappingURL=PdfView.d.ts.map