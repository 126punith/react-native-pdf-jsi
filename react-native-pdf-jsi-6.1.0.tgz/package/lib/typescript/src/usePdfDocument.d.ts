import type { PdfDocument } from './specs/PdfLibrary.nitro';
import { type PdfLoadProgress } from './PdfCache';
import { PdfError } from './errors';
import { type PdfSource } from './source';
export interface UsePdfDocumentOptions {
    password?: string;
    onLoadProgress?: (progress: PdfLoadProgress) => void;
}
export interface UsePdfDocumentResult {
    /** Open document, shared with other users of the same path. Do not call close() on it. */
    document: PdfDocument | null;
    path: string | null;
    loading: boolean;
    error: PdfError | null;
}
/**
 * Loads a source (downloading and caching remote files) and opens it as a
 * PdfDocument. The document is released when the source changes or the
 * component unmounts.
 */
export declare function usePdfDocument(source: PdfSource | null | undefined, options?: UsePdfDocumentOptions): UsePdfDocumentResult;
export default usePdfDocument;
//# sourceMappingURL=usePdfDocument.d.ts.map