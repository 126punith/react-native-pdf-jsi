export default PDFText;
declare class PDFText {
    static setOCREngine(engine: any): void;
    static clearOCREngine(): void;
    static getOCREngine(): any;
    static isAvailable(): boolean;
    static isOCRAvailable(): Promise<boolean>;
    static getCapabilities(): Promise<{
        textExtraction: boolean;
        ocr: boolean;
        customEngineSupported: boolean;
        customEngineRegistered: boolean;
        recognizePage: boolean;
        searchablePdf: boolean;
        platform: "ios" | "android" | "windows" | "macos" | "web";
        ocrBuildEnabled: boolean;
    }>;
    static getPageSize(filePath: any, pageIndex0: any): Promise<any>;
    /**
     * Map OCR pageMeta blocks to PdfView `highlights` (zero-based pages, PdfRect in points).
     * @param {string} filePath
     * @param {Map|Object} pageMeta - from extract({ includeBlocks: true })
     * @returns {Promise<Array<{ page: number, rect: { x: number, y: number, width: number, height: number } }>>}
     */
    static toHighlightRects(filePath: string, pageMeta: Map<any, any> | Object): Promise<Array<{
        page: number;
        rect: {
            x: number;
            y: number;
            width: number;
            height: number;
        };
    }>>;
    /**
     * Sync helper when page sizes / image sizes are already on pageMeta.
     */
    static blocksToHighlightRects(pageMeta: any): {
        page: any;
        rect: {
            x: number;
            y: number;
            width: number;
            height: number;
        };
    }[];
    /**
     * Extract text from a PDF.
     * @returns {Promise<{ pages, fullText, stats, pageMeta? }>}
     */
    static extract(filePath: any, options?: {}): Promise<{
        pages: any;
        fullText: any;
        stats: any;
        pageMeta?: any;
    }>;
    /**
     * Not supported: assemble a searchable PDF from recognizePage results instead.
     */
    static makeSearchablePDF(): Promise<void>;
    static extractTextFromPage(filePath: any, pageIndex: any): Promise<any>;
    static extractTextFromPages(filePath: any, pageIndices: any): Promise<Map<any, any>>;
    static extractAllText(filePath: any): Promise<Map<any, any>>;
    static getPageCount(filePath: any): Promise<any>;
    static recognizeImage(imagePath: any, options?: {}): Promise<void | {
        text: string;
        blocks: never[];
        engine: string;
        imageWidth?: undefined;
        imageHeight?: undefined;
    } | {
        text: any;
        blocks: any;
        engine: any;
        imageWidth: any;
        imageHeight: any;
    }>;
    /**
     * In-memory OCR for a PDF page (native). Falls back to export path if needed.
     */
    static recognizePage(filePath: any, pageIndex0: any, options?: {}): Promise<{
        imagePath: any;
        imageWidth: any;
        imageHeight: any;
        pageSize: any;
        tempImage: boolean;
        text?: undefined;
        blocks?: undefined;
        engine?: undefined;
    } | {
        imagePath: any;
        imageWidth: any;
        imageHeight: any;
        pageSize: any;
        tempImage: boolean;
        text: any;
        blocks: any;
        engine: any;
    } | {
        text: any;
        blocks: never[];
        engine: string;
        imageWidth: any;
        imageHeight: any;
        pageSize: any;
        tempImage: boolean;
    }>;
}
//# sourceMappingURL=PDFText.d.ts.map