export default BookmarkModal;
declare function BookmarkModal({ visible, onClose, onSave, currentPage, initialData, }: {
    visible: any;
    onClose: any;
    onSave: any;
    currentPage: any;
    initialData: any;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=BookmarkModal.d.ts.map