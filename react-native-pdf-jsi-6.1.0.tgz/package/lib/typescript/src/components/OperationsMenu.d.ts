export default OperationsMenu;
declare function OperationsMenu({ visible, onClose, pdfPath, totalPages, onOperation, }: {
    visible: any;
    onClose: any;
    pdfPath: any;
    totalPages: any;
    onOperation: any;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=OperationsMenu.d.ts.map