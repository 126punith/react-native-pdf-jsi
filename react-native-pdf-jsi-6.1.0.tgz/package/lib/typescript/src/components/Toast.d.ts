export default Toast;
declare function Toast({ visible, message, type, duration, onHide, }: {
    visible: any;
    message: any;
    type?: string | undefined;
    duration?: number | undefined;
    onHide: any;
}): React.JSX.Element | null;
import React from 'react';
//# sourceMappingURL=Toast.d.ts.map