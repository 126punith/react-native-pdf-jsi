export default AnalyticsPanel;
declare function AnalyticsPanel({ visible, onClose, analytics, licenseInfo, }: {
    visible: any;
    onClose: any;
    analytics: any;
    licenseInfo: any;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=AnalyticsPanel.d.ts.map