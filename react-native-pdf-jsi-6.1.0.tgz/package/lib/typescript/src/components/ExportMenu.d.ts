export default ExportMenu;
declare function ExportMenu({ visible, onClose, currentPage, totalPages, pdfPath, onExport, onShareFiles, }: {
    visible: any;
    onClose: any;
    currentPage: any;
    totalPages: any;
    pdfPath: any;
    onExport: any;
    onShareFiles: any;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=ExportMenu.d.ts.map