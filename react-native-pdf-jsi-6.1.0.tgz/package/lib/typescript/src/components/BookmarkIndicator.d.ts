export default BookmarkIndicator;
declare function BookmarkIndicator({ hasBookmark, bookmarkColor, bookmarkCount, onPress, }: {
    hasBookmark: any;
    bookmarkColor?: string | undefined;
    bookmarkCount?: number | undefined;
    onPress: any;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=BookmarkIndicator.d.ts.map