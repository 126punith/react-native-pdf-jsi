export default SidePanel;
declare function SidePanel({ visible, onClose, children, side, width, }: {
    visible: any;
    onClose: any;
    children: any;
    side?: string | undefined;
    width?: number | undefined;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=SidePanel.d.ts.map