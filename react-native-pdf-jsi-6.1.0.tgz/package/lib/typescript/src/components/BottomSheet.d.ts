export default BottomSheet;
declare function BottomSheet({ visible, onClose, children, height, }: {
    visible: any;
    onClose: any;
    children: any;
    height?: number | undefined;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=BottomSheet.d.ts.map