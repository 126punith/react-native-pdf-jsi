export default BookmarkListModal;
declare function BookmarkListModal({ visible, onClose, bookmarks, onNavigate, onDelete, currentPage, }: {
    visible: any;
    onClose: any;
    bookmarks: any;
    onNavigate: any;
    onDelete: any;
    currentPage: any;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=BookmarkListModal.d.ts.map