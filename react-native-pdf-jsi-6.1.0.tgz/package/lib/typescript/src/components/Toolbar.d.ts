export default Toolbar;
declare function Toolbar({ title, subtitle, buttons, onBack, }: {
    title: any;
    subtitle: any;
    buttons: any;
    onBack: any;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=Toolbar.d.ts.map