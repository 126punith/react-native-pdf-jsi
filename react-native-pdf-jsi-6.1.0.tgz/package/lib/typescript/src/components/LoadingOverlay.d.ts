export default LoadingOverlay;
declare function LoadingOverlay({ visible, message, }: {
    visible: any;
    message?: string | undefined;
}): React.JSX.Element;
import React from 'react';
//# sourceMappingURL=LoadingOverlay.d.ts.map