/**
 * Error codes are stable and identical on iOS and Android. Messages are for
 * people and may change: match on `error.code`.
 */
export type PdfErrorCode = 'invalid-source' | 'download-failed' | 'password-required' | 'password-incorrect' | 'unsupported-pdf' | 'page-render-failed' | 'out-of-memory' | 'invalid-page' | 'invalid-argument' | 'unsupported-operation' | 'io-error' | 'cancelled' | 'document-closed' | 'unknown';
export declare const PDF_ERROR_CODES: readonly PdfErrorCode[];
export declare class PdfError extends Error {
    readonly code: PdfErrorCode;
    readonly page?: number;
    readonly cause?: unknown;
    constructor(code: PdfErrorCode, message: string, options?: {
        page?: number;
        cause?: unknown;
    });
}
export declare function isPdfError(value: unknown): value is PdfError;
/**
 * Native code reports errors as `[code] message`. Nitro may wrap the message
 * (for example `Error: [code] message`), so the prefix is searched, not anchored.
 */
export declare function parseNativeError(message: string): {
    code: PdfErrorCode;
    message: string;
};
/** Turns anything thrown by native code or JS into a PdfError. */
export declare function toPdfError(error: unknown, fallback?: PdfErrorCode): PdfError;
/** Default English messages for display. Apps can provide their own per code. */
export declare const DEFAULT_ERROR_MESSAGES: Record<PdfErrorCode, string>;
export declare function errorMessageFor(error: unknown): string;
//# sourceMappingURL=errors.d.ts.map