import type { NormalizedSource, PdfCacheMode } from './source';
import type { PdfSource } from './source';
import type { PdfCacheEntry, PdfDownloadsTarget } from './specs/PdfCache.nitro';
export type { PdfCacheEntry, PdfDownloadsTarget };
export interface PdfLoadProgress {
    loadedBytes: number;
    /** `undefined` when the server did not send a length. */
    totalBytes?: number;
}
export interface LoadOptions {
    onProgress?: (progress: PdfLoadProgress) => void;
    signal?: AbortSignal;
}
export interface LoadedSource {
    path: string;
    /** Set for remote sources. */
    entry?: PdfCacheEntry;
}
/** Downloads, copies or decodes a normalized source into a local file and returns its path. */
export declare function loadNormalizedSource(source: NormalizedSource, options?: LoadOptions): Promise<LoadedSource>;
/** Public cache API. Downloads happen natively; nothing goes through JS memory. */
export declare const PdfCache: {
    /** Downloads (or revalidates) a remote document ahead of time. */
    download(source: PdfSource, options?: LoadOptions): Promise<PdfCacheEntry>;
    getEntry(source: PdfSource): Promise<PdfCacheEntry | undefined>;
    /** Removes a stored copy by its entry key. */
    remove(key: string): Promise<boolean>;
    clear(): Promise<void>;
    getByteSize(): Promise<number>;
    maxCacheBytes: number;
};
export type { PdfCacheMode };
/** Local-file helpers that replace react-native-blob-util for this library. */
export declare const PdfFiles: {
    readonly cacheDirectory: string;
    readonly documentDirectory: string;
    exists: (path: string) => Promise<boolean>;
    size: (path: string) => Promise<number>;
    copy: (from: string, to: string) => Promise<void>;
    remove: (path: string) => Promise<boolean>;
    /** Android: the public Downloads folder. iOS: the app's Documents folder. */
    saveToDownloads: (path: string, fileName: string, mimeType?: string) => Promise<PdfDownloadsTarget>;
};
//# sourceMappingURL=PdfCache.d.ts.map