import * as React from 'react';
import type { StyleProp, ViewProps, ViewStyle } from 'react-native';
import { PdfError } from './errors';
import type { PdfDocument } from './specs/PdfLibrary.nitro';
export interface PdfPageProps extends Omit<ViewProps, 'children' | 'style'> {
    /** An open document, for example from `usePdfDocument`. Its in-memory edits are shown. */
    document: PdfDocument;
    /** Zero-based page. */
    page: number;
    /** Change it to redraw after editing the document. */
    revision?: number;
    enableAnnotationRendering?: boolean;
    /** The page's aspect ratio is applied unless the style sets both width and height. */
    style?: StyleProp<ViewStyle>;
    /** Pixel size of the drawn bitmap. */
    onRender?: (size: {
        width: number;
        height: number;
    }) => void;
    onError?: (error: PdfError) => void;
}
/**
 * Draws one page of an open `PdfDocument`, sized by the page's aspect ratio.
 * Use it for thumbnails, page pickers and custom layouts.
 */
export declare function PdfPage({ document, page, revision, enableAnnotationRendering, style, onRender, onError, ...viewProps }: PdfPageProps): React.ReactElement | null;
//# sourceMappingURL=PdfPage.d.ts.map