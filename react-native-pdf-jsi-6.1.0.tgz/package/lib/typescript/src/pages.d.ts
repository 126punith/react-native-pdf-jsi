/**
 * Returns a valid zero-based page index, or `null` for values that are not a
 * whole, finite, non-negative number. `NaN` usually comes from parsing user
 * input (`Number('a') - 1`), where doing nothing is the expected result.
 * When `pageCount` is known, the index is clamped to the last page.
 */
export declare function toPageIndex(value: unknown, pageCount?: number): number | null;
/** Like `toPageIndex`, but rejects with `invalid-page` instead of returning `null`. */
export declare function requirePageIndex(value: unknown, pageCount?: number): number;
/** A positive, finite scale, or `null`. */
export declare function toScale(value: unknown): number | null;
//# sourceMappingURL=pages.d.ts.map