/**
 * Nitro entry point and the document registry.
 *
 * Native documents are owned by a reference-counted registry. Hermes cannot
 * see the native memory behind a PdfDocument, so documents are closed
 * explicitly: when the last reference is released (after a small warm pool),
 * when the file is replaced (invalidatePdf), or on a memory warning.
 */
import type { PdfCache } from './specs/PdfCache.nitro';
import type { PdfDocument, PdfLibrary } from './specs/PdfLibrary.nitro';
export declare function getPdfLibrary(): PdfLibrary;
export declare function getPdfCache(): PdfCache;
/**
 * Takes a reference on the document at `path`, opening it if needed.
 * Every acquirePdf must be paired with releasePdf.
 */
export declare function acquirePdf(path: string, password?: string): Promise<PdfDocument>;
/** Releases a reference taken with acquirePdf (by path or document handle). */
export declare function releasePdf(pathOrDocument: string | PdfDocument): void;
/** Runs `fn(document)` while holding a reference; always releases it. */
export declare function withPdfDocument<T>(path: string, fn: (document: PdfDocument) => T | Promise<T>, password?: string): Promise<T>;
/**
 * Call when the file at `path` is about to be replaced or deleted. The next
 * acquire opens a fresh document; the old one closes once nothing uses it.
 */
export declare function invalidatePdf(path: string): void;
/** Closes every released document kept warm for fast reopen. */
export declare function trimPdfCache(): void;
/** Force-closes every document, including referenced and pinned ones. */
export declare function closeAllPdfs(): void;
export interface PdfRegistryStats {
    open: number;
    referenced: number;
    pinned: number;
    warm: number;
    stale: number;
}
export declare function getPdfRegistryStats(): PdfRegistryStats;
/**
 * Opens and pins the document at `path`. A pinned document stays open until
 * closePdf(path). Prefer withPdfDocument or acquirePdf/releasePdf.
 */
export declare function openPdf(path: string, password?: string): Promise<PdfDocument>;
/** Force-closes the document at `path`, even if it is still referenced. */
export declare function closePdf(path: string): void;
/** Whether the Nitro module is installed and linked. */
export declare function isPdfModuleAvailable(): boolean;
export declare function check16KBSupport(): import("./specs/PdfLibrary.nitro").KB16Support;
//# sourceMappingURL=PDFJSI.d.ts.map