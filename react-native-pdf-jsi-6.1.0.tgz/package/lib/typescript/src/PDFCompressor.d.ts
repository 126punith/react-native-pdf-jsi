export namespace CompressionPreset {
    let EMAIL: string;
    let WEB: string;
    let MOBILE: string;
    let PRINT: string;
    let ARCHIVE: string;
    let CUSTOM: string;
}
export namespace CompressionLevel {
    let NONE: number;
    let FASTEST: number;
    let FAST: number;
    let BALANCED: number;
    let DEFAULT: number;
    let GOOD: number;
    let BETTER: number;
    let BEST: number;
}
/**
 * PDFCompressor Class
 * Provides PDF compression functionality with streaming support
 */
export class PDFCompressor {
    isNativeAvailable: boolean;
    /**
     * Check if native compression module is available
     * @private
     * @returns {boolean} True if native module is available
     */
    private _checkNativeAvailability;
    /**
     * Check if compression is available
     * @returns {boolean} True if compression functionality is available
     */
    isAvailable(): boolean;
    /**
     * Get compression capabilities
     * @returns {Object} Capabilities object
     */
    getCapabilities(): Object;
    /**
     * Get preset configuration
     * @param {string} preset - Preset name from CompressionPreset
     * @returns {Object} Preset configuration
     */
    getPresetConfig(preset: string): Object;
    /**
     * Compress a PDF file
     * @param {string} inputPath - Path to input PDF file
     * @param {Object} options - Compression options
     * @param {string} options.preset - Compression preset (from CompressionPreset)
     * @param {number} options.level - Compression level (0-9), overrides preset
     * @param {string} options.outputPath - Output file path (optional, auto-generated if not provided)
     * @param {Function} options.onProgress - Progress callback function
     * @returns {Promise<Object>} Compression result
     */
    compress(inputPath: string, options?: {
        preset: string;
        level: number;
        outputPath: string;
        onProgress: Function;
    }): Promise<Object>;
    /**
     * Compress PDF with a specific preset
     * @param {string} inputPath - Path to input PDF file
     * @param {string} preset - Compression preset
     * @param {string} outputPath - Output file path (optional)
     * @returns {Promise<Object>} Compression result
     */
    compressWithPreset(inputPath: string, preset: string, outputPath?: string): Promise<Object>;
    /**
     * Compress PDF for email (maximum compression)
     * @param {string} inputPath - Path to input PDF file
     * @param {string} outputPath - Output file path (optional)
     * @returns {Promise<Object>} Compression result
     */
    compressForEmail(inputPath: string, outputPath?: string): Promise<Object>;
    /**
     * Compress PDF for web viewing
     * @param {string} inputPath - Path to input PDF file
     * @param {string} outputPath - Output file path (optional)
     * @returns {Promise<Object>} Compression result
     */
    compressForWeb(inputPath: string, outputPath?: string): Promise<Object>;
    /**
     * Compress PDF for mobile viewing
     * @param {string} inputPath - Path to input PDF file
     * @param {string} outputPath - Output file path (optional)
     * @returns {Promise<Object>} Compression result
     */
    compressForMobile(inputPath: string, outputPath?: string): Promise<Object>;
    /**
     * Compress PDF for archival (maximum compression)
     * @param {string} inputPath - Path to input PDF file
     * @param {string} outputPath - Output file path (optional)
     * @returns {Promise<Object>} Compression result
     */
    compressForArchive(inputPath: string, outputPath?: string): Promise<Object>;
    /**
     * Estimate compression result without actually compressing
     * @param {string} inputPath - Path to input PDF file
     * @param {string} preset - Compression preset
     * @returns {Promise<Object>} Estimated compression result
     */
    estimateCompression(inputPath: string, preset?: string): Promise<Object>;
    /**
     * Native compression using PDFExporter.compressPDF
     * @private
     */
    private _compressNative;
    /**
     * Fallback compression (file copy with potential optimization)
     * @private
     */
    private _compressFallback;
    /**
     * Check if file exists
     * @private
     */
    private _fileExists;
    /**
     * Get file statistics
     * @private
     */
    private _getFileStats;
    /**
     * Generate output path based on input path
     * @private
     */
    private _generateOutputPath;
    /**
     * Delete a compressed file
     * @param {string} filePath - Path to file to delete
     * @returns {Promise<boolean>} Success status
     */
    deleteCompressedFile(filePath: string): Promise<boolean>;
    /**
     * Get module information
     * @returns {Object} Module info
     */
    getModuleInfo(): Object;
}
export default pdfCompressor;
declare const pdfCompressor: PDFCompressor;
//# sourceMappingURL=PDFCompressor.d.ts.map